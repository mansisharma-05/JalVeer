from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.routes import country, weapons, comparison
from app.routes import selection

app = FastAPI(title="Naval Weapon Comparison API")

# Include routes
app.include_router(country.router)
app.include_router(weapons.router)
app.include_router(selection.router)
app.include_router(comparison.router)

# Static images route
app.mount("/static", StaticFiles(directory="app/static"), name="static")